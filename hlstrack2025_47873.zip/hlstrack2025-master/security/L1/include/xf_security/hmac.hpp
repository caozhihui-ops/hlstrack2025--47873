/*
 * Copyright 2019 Xilinx, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @file hmac.hpp
 * @brief header file for HMAC.
 * This file part of Vitis Security Library.
 * Optimized for low latency
 * @detail Optimized HMAC implementation with reduced latency through pipelining and parallelization.
 */

#ifndef _XF_SECURITY_HMAC_HPP_
#define _XF_SECURITY_HMAC_HPP_

#include <ap_int.h>
#include <hls_stream.h>
#include <xf_security/types.hpp>

#if !defined(__SYNTHESIS__) && XF_SECURITY_DECRYPT_DEBUG == 1
#include <iostream>
#endif

namespace xf {
namespace security {

namespace internal {

// 流缓冲辅助函数 - 预读取数据减少等待时间
template <int dataW, int lW>
void buffer_streams(hls::stream<ap_uint<dataW> >& inStrm,
                   hls::stream<ap_uint<lW> >& lenStrm,
                   hls::stream<bool>& eStrm,
                   hls::stream<ap_uint<dataW> >& outStrm,
                   hls::stream<ap_uint<lW> >& outLenStrm,
                   hls::stream<bool>& eOutStrm) {
#pragma HLS PIPELINE II=1
#pragma HLS LATENCY max=10
    
    while (!eStrm.read()) {
        ap_uint<lW> len = lenStrm.read();
        outLenStrm.write(len);
        eOutStrm.write(false);
        
        int iterations = (len * 8 + dataW - 1) / dataW;
        for (int i = 0; i < iterations; i++) {
        #pragma HLS PIPELINE II=1
            outStrm.write(inStrm.read());
        }
    }
    eOutStrm.write(true);
}

// 复制布尔流的辅助函数
void copy_bool_stream(hls::stream<bool>& src, hls::stream<bool>& dst) {
#pragma HLS PIPELINE II=1
#pragma HLS LATENCY max=5
    bool e;
    do {
        e = src.read();
        dst.write(e);
    } while (!e);
}

template <int lW, int keyLen>
void expandStrm(hls::stream<bool>& eInStrm, hls::stream<bool>& eOutStrm, hls::stream<ap_uint<lW> >& lenStrm) {
#pragma HLS PIPELINE II=1
#pragma HLS LATENCY max=5
    while (!eInStrm.read()) {
        eOutStrm.write(false);
        lenStrm.write(ap_uint<lW>(keyLen));
    }
    eOutStrm.write(true);
}

template <int dataW, int hshW, int blockSize>
void genPad_optimized(hls::stream<ap_uint<hshW> >& keyHashStrm,
                     hls::stream<bool>& ekeyHashStrm,
                     hls::stream<ap_uint<blockSize * 8> >& kipadStrm,
                     hls::stream<ap_uint<blockSize * 8> >& kopadStrm,
                     hls::stream<bool>& eKipadStrm) {
    
    while (!ekeyHashStrm.read()) {
    #pragma HLS PIPELINE II = 1
    #pragma HLS LATENCY max=15
        
        ap_uint<hshW> keyHash = keyHashStrm.read();
        ap_uint<blockSize* 8> kipad = 0;
        ap_uint<blockSize* 8> kopad = 0;
        ap_uint<blockSize* 8> k1 = 0;

        // 使用更高效的位操作 - 完全展开循环
        const int elements = hshW / dataW;
        for (int i = 0; i < elements; i++) {
        #pragma HLS UNROLL
            ap_uint<dataW> segment = keyHash.range((i+1)*dataW-1, i*dataW);
            k1.range(blockSize*8 - i*dataW - 1, blockSize*8 - (i+1)*dataW) = segment;
        }

        // 并行计算ipad和opad - 完全展开
        for (int i = 0; i < blockSize; i++) {
        #pragma HLS UNROLL
            ap_uint<8> byte_val = k1.range(i*8+7, i*8);
            kipad.range(i*8+7, i*8) = byte_val ^ 0x36;
            kopad.range(i*8+7, i*8) = byte_val ^ 0x5c;
        }

        kipadStrm.write(kipad);
        kopadStrm.write(kopad);
        eKipadStrm.write(false);
    }
    eKipadStrm.write(true);
}

template <int dataW, int lW, int hshW, int keyLen, int blockSize, template <int iW, int ilW, int oW> class F>
void kpadHash(hls::stream<ap_uint<dataW> >& keyStrm,
              hls::stream<bool>& eStrm,
              hls::stream<ap_uint<blockSize * 8> >& kipadStrm,
              hls::stream<ap_uint<blockSize * 8> >& kopadStrm,
              hls::stream<bool>& eKipadStrm) {
#pragma HLS DATAFLOW

    hls::stream<bool> eKeyStrm;
#pragma HLS STREAM variable = eKeyStrm depth = 16
    hls::stream<ap_uint<lW> > keyLenStrm;
#pragma HLS STREAM variable = keyLenStrm depth = 16
    hls::stream<ap_uint<hshW> > keyHashStrm;
#pragma HLS STREAM variable = keyHashStrm depth = 16
    hls::stream<bool> ekeyHashStrm;
#pragma HLS STREAM variable = ekeyHashStrm depth = 16

    expandStrm<lW, keyLen>(eStrm, eKeyStrm, keyLenStrm);

    F<dataW, lW, hshW>::hash(keyStrm, keyLenStrm, eKeyStrm, keyHashStrm, ekeyHashStrm);

    genPad_optimized<dataW, hshW, blockSize>(keyHashStrm, ekeyHashStrm, kipadStrm, kopadStrm, eKipadStrm);
}

template <int dataW, int lW, int hshW, int keyLen, int blockSize, template <int iW, int ilW, int oW> class F>
void kpad_optimized(hls::stream<ap_uint<dataW> >& keyStrm,
                   hls::stream<bool>& eStrm,
                   hls::stream<ap_uint<blockSize * 8> >& kipadStrm,
                   hls::stream<ap_uint<blockSize * 8> >& kopadStrm,
                   hls::stream<bool>& eKipadStrm) {
    
    if (keyLen > blockSize) {
        kpadHash<dataW, lW, hshW, keyLen, blockSize, F>(keyStrm, eStrm, kipadStrm, kopadStrm, eKipadStrm);
    } else {
        while (!eStrm.read()) {
        #pragma HLS PIPELINE II=1
        #pragma HLS LATENCY max=12
            
            ap_uint<blockSize* 8> k1 = 0;
            int keyWords = (keyLen * 8 + dataW - 1) / dataW;
            
            // 优化关键路径 - 减少循环迭代
            for (int i = 0; i < keyWords; i++) {
            #pragma HLS PIPELINE II=1
                ap_uint<dataW> tmp = keyStrm.read();
                k1 <<= dataW;
                k1.range(dataW - 1, 0) = tmp;
            }
            
            // 左对齐数据
            k1 <<= (blockSize * 8 - keyWords * dataW);
            
            ap_uint<blockSize* 8> kipad = 0;
            ap_uint<blockSize* 8> kopad = 0;
            
            // 并行计算 - 完全展开
            for (int i = 0; i < blockSize; i++) {
            #pragma HLS UNROLL
                ap_uint<8> byte_val = k1.range(blockSize*8 - i*8 - 1, blockSize*8 - (i+1)*8);
                kipad.range(blockSize*8 - i*8 - 1, blockSize*8 - (i+1)*8) = byte_val ^ 0x36;
                kopad.range(blockSize*8 - i*8 - 1, blockSize*8 - (i+1)*8) = byte_val ^ 0x5c;
            }
            
            kipadStrm.write(kipad);
            kopadStrm.write(kopad);
            eKipadStrm.write(false);
        }
        eKipadStrm.write(true);
    }
}

template <int dataW, int lW, int hshW, int blockSize>
void mergeKipad_optimized(hls::stream<ap_uint<blockSize * 8> >& kipadStrm,
                         hls::stream<ap_uint<blockSize * 8> >& kopadInStrm,
                         hls::stream<ap_uint<dataW> >& msgStrm,
                         hls::stream<ap_uint<lW> >& msgLenStrm,
                         hls::stream<bool>& eLenStrm2,
                         hls::stream<ap_uint<dataW> >& mergeKipadStrm,
                         hls::stream<ap_uint<lW> >& mergeKipadLenStrm,
                         hls::stream<bool>& eMergeKipadLenStrm,
                         hls::stream<ap_uint<blockSize * 8> >& kopadOutStrm) {
    
    // 增加流深度以容忍处理延迟
#pragma HLS STREAM variable = mergeKipadStrm depth = 512
#pragma HLS STREAM variable = kopadOutStrm depth = 32
    
    while (!eLenStrm2.read()) {
    #pragma HLS PIPELINE II = 1
    #pragma HLS LATENCY max=20
        
        eMergeKipadLenStrm.write(false);
        ap_uint<lW> ml = msgLenStrm.read();
        ap_uint<lW> mergeKipadLen = ml + blockSize;
        mergeKipadLenStrm.write(mergeKipadLen);

        ap_uint<blockSize* 8> kipad = kipadStrm.read();
        ap_uint<blockSize* 8> kopad = kopadInStrm.read();

        // 优化数据输出 - 部分展开以提高吞吐量
        const int iterations = (blockSize * 8 + dataW - 1) / dataW;
        
        for (int i = 0; i < iterations; i++) {
        #pragma HLS PIPELINE II=1
            mergeKipadStrm.write(kipad.range(blockSize * 8 - 1, blockSize * 8 - dataW));
            kipad <<= dataW;
        }

        kopadOutStrm.write(kopad);

        // 消息数据流处理 - 保持流水线
        int msg_iterations = (ml * 8 + dataW - 1) / dataW;
        for (int i = 0; i < msg_iterations; i++) {
        #pragma HLS PIPELINE II=1
            mergeKipadStrm.write(msgStrm.read());
        }
    }
    eMergeKipadLenStrm.write(true);
}

template <int dataW, int lW, int hshW, int keyLen, int blockSize, template <int iW, int ilW, int oW> class F>
void msgHash_optimized(hls::stream<ap_uint<blockSize * 8> >& kipadStrm,
                      hls::stream<ap_uint<blockSize * 8> >& kopadInStrm,
                      hls::stream<ap_uint<dataW> >& msgStrm,
                      hls::stream<ap_uint<lW> >& msgLenStrm,
                      hls::stream<bool>& eLenStrm,
                      hls::stream<ap_uint<blockSize * 8> >& kopadOutStrm,
                      hls::stream<ap_uint<hshW> >& msgHashStrm,
                      hls::stream<bool>& eMsgHashStrm) {
#pragma HLS DATAFLOW

    hls::stream<ap_uint<dataW> > mergeKipadStrm;
#pragma HLS STREAM variable = mergeKipadStrm depth = 512
    hls::stream<ap_uint<lW> > mergeKipadLenStrm;
#pragma HLS STREAM variable = mergeKipadLenStrm depth = 16
    hls::stream<bool> eMergeKipadLenStrm;
#pragma HLS STREAM variable = eMergeKipadLenStrm depth = 16

    mergeKipad_optimized<dataW, lW, hshW, blockSize>(kipadStrm, kopadInStrm, msgStrm, msgLenStrm, eLenStrm, 
                                                    mergeKipadStrm, mergeKipadLenStrm, eMergeKipadLenStrm, 
                                                    kopadOutStrm);

    F<dataW, lW, hshW>::hash(mergeKipadStrm, mergeKipadLenStrm, eMergeKipadLenStrm, msgHashStrm, eMsgHashStrm);
}

template <int dataW, int lW, int hshW, int keyLen, int blockSize>
void mergeKopad_optimized(hls::stream<ap_uint<blockSize * 8> >& kopadStrm,
                         hls::stream<ap_uint<hshW> >& msgHashStrm,
                         hls::stream<bool>& eMsgHashStrm,
                         hls::stream<ap_uint<dataW> >& mergeKopadStrm,
                         hls::stream<ap_uint<lW> >& mergeKopadLenStrm,
                         hls::stream<bool>& eMergeKopadLenStrm) {
    
    // 增加流深度
#pragma HLS STREAM variable = mergeKopadStrm depth = 256
#pragma HLS STREAM variable = mergeKopadLenStrm depth = 16
    
    while (!eMsgHashStrm.read()) {
    #pragma HLS PIPELINE II=1
    #pragma HLS LATENCY max=15
        
        eMergeKopadLenStrm.write(false);
        mergeKopadLenStrm.write(ap_uint<lW>(blockSize + hshW / 8));

        ap_uint<blockSize* 8> kopad = kopadStrm.read();
        ap_uint<hshW> msgHash = msgHashStrm.read();

        // 优化数据输出
        const int kopad_iterations = (blockSize * 8 + dataW - 1) / dataW;
        for (int i = 0; i < kopad_iterations; i++) {
        #pragma HLS PIPELINE II=1
            mergeKopadStrm.write(kopad.range(blockSize * 8 - 1, blockSize * 8 - dataW));
            kopad <<= dataW;
        }

        // 优化哈希值输出
        const int hash_iterations = (hshW + dataW - 1) / dataW;
        for (int i = 0; i < hash_iterations; i++) {
        #pragma HLS PIPELINE II=1
            mergeKopadStrm.write(msgHash.range(dataW - 1, 0));
            msgHash >>= dataW;
        }
    }
    eMergeKopadLenStrm.write(true);
}

template <int dataW, int lW, int hshW, int keyLen, int blockSize, template <int iW, int ilW, int oW> class F>
void resHash_optimized(hls::stream<ap_uint<blockSize * 8> >& kopadStrm,
                      hls::stream<ap_uint<hshW> >& msgHashStrm,
                      hls::stream<bool>& eMsgHashStrm,
                      hls::stream<ap_uint<hshW> >& hshStrm,
                      hls::stream<bool>& eHshStrm) {
#pragma HLS DATAFLOW

    hls::stream<ap_uint<dataW> > mergeKopadStrm;
#pragma HLS STREAM variable = mergeKopadStrm depth = 256
    hls::stream<ap_uint<lW> > mergeKopadLenStrm;
#pragma HLS STREAM variable = mergeKopadLenStrm depth = 16
    hls::stream<bool> eMergeKopadLenStrm;
#pragma HLS STREAM variable = eMergeKopadLenStrm depth = 16

    mergeKopad_optimized<dataW, lW, hshW, keyLen, blockSize>(kopadStrm, msgHashStrm, eMsgHashStrm, mergeKopadStrm,
                                                            mergeKopadLenStrm, eMergeKopadLenStrm);

    F<dataW, lW, hshW>::hash(mergeKopadStrm, mergeKopadLenStrm, eMergeKopadLenStrm, hshStrm, eHshStrm);
}

template <int dataW, int lW, int hshW, int keyLen, int blockSize, template <int iW, int ilW, int oW> class F>
void hmacDataflow_optimized(hls::stream<ap_uint<dataW> >& keyStrm,
                           hls::stream<ap_uint<dataW> >& msgStrm,
                           hls::stream<ap_uint<lW> >& msgLenStrm,
                           hls::stream<bool>& eLenStrm,
                           hls::stream<ap_uint<hshW> >& hshStrm,
                           hls::stream<bool>& eHshStrm) {
#pragma HLS DATAFLOW
    
    // 增加所有关键数据流的深度
    hls::stream<bool> eKipadStrm;
#pragma HLS STREAM variable = eKipadStrm depth = 32

    hls::stream<ap_uint<blockSize * 8> > kipadStrm;
#pragma HLS STREAM variable = kipadStrm depth = 32
    hls::stream<ap_uint<blockSize * 8> > kopadStrm;
#pragma HLS STREAM variable = kopadStrm depth = 32
    hls::stream<ap_uint<blockSize * 8> > kopad2Strm;
#pragma HLS STREAM variable = kopad2Strm depth = 32

    hls::stream<ap_uint<hshW> > msgHashStrm;
#pragma HLS STREAM variable = msgHashStrm depth = 32
    hls::stream<bool> eMsgHashStrm;
#pragma HLS STREAM variable = eMsgHashStrm depth = 32

    // 使用缓冲流预处理输入数据
    hls::stream<ap_uint<dataW> > msgBufferStrm;
    hls::stream<ap_uint<lW> > msgLenBufferStrm;
    hls::stream<bool> eLenBufferStrm;
#pragma HLS STREAM variable = msgBufferStrm depth = 512
#pragma HLS STREAM variable = msgLenBufferStrm depth = 32
#pragma HLS STREAM variable = eLenBufferStrm depth = 32

    buffer_streams<dataW, lW>(msgStrm, msgLenStrm, eLenStrm, 
                             msgBufferStrm, msgLenBufferStrm, eLenBufferStrm);

    // 并行处理关键路径
    kpad_optimized<dataW, lW, hshW, keyLen, blockSize, F>(keyStrm, eLenBufferStrm, kipadStrm, kopadStrm, eKipadStrm);

    // 重新创建长度流用于后续处理 - 修复：使用复制函数而不是 >> 操作符
    hls::stream<bool> eLenStrm2;
#pragma HLS STREAM variable = eLenStrm2 depth = 32
    
    // 修复：使用复制函数而不是 >> 操作符
    copy_bool_stream(eKipadStrm, eLenStrm2);

    msgHash_optimized<dataW, lW, hshW, keyLen, blockSize, F>(kipadStrm, kopadStrm, msgBufferStrm, msgLenBufferStrm, 
                                                            eLenStrm2, kopad2Strm, msgHashStrm, eMsgHashStrm);

    resHash_optimized<dataW, lW, hshW, keyLen, blockSize, F>(kopad2Strm, msgHashStrm, eMsgHashStrm, hshStrm, eHshStrm);
}

} // end of namespace internal

/**
 * @brief Compute HMAC value according to specified hash function and input data.
 *
 * Optimized version with reduced latency through pipelining and parallelization.
 *
 * @tparam dataW the width of input stream keyStrm and msgStrm.
 * @tparam lW the with of input msgLenstrm.
 * @tparam blockSize  the block size (in bytes) of the underlying hash function (e.g. 64 bytes for md5 and SHA-1).
 * @tparam hshW the width of output stream hshStrm.
 * @tparam keyLen lenght of key (in bytes)
 * @tparam F a wrapper of hash function which must have a static fucntion named `hash`.
 *
 * @param keyStrm  input key stream.
 * @param msgStrm  input meassge stream.
 * @param msgLenStrm  the length stream of input message stream.
 * @param eLenStrm  the end flag of length stream.
 * @param hshStrm output stream.
 * @param eHshStrm end flag of output stream hshStrm.
 *
 */
template <int dataW, int lW, int hshW, int keyLen, int blockSize, template <int iW, int ilW, int oW> class F>
void hmac_optimized(hls::stream<ap_uint<dataW> >& keyStrm,
                   hls::stream<ap_uint<dataW> >& msgStrm,
                   hls::stream<ap_uint<lW> >& msgLenStrm,
                   hls::stream<bool>& eLenStrm,
                   hls::stream<ap_uint<hshW> >& hshStrm,
                   hls::stream<bool>& eHshStrm) {
    
    // 增加顶层流深度配置
#pragma HLS STREAM variable = keyStrm depth = 64
#pragma HLS STREAM variable = msgStrm depth = 512  
#pragma HLS STREAM variable = hshStrm depth = 32
    
    internal::hmacDataflow_optimized<dataW, lW, hshW, keyLen, blockSize, F>(keyStrm, msgStrm, msgLenStrm, eLenStrm, 
                                                                            hshStrm, eHshStrm);
}

// 保持向后兼容的原始接口
template <int dataW, int lW, int hshW, int keyLen, int blockSize, template <int iW, int ilW, int oW> class F>
void hmac(hls::stream<ap_uint<dataW> >& keyStrm,
          hls::stream<ap_uint<dataW> >& msgStrm,
          hls::stream<ap_uint<lW> >& msgLenStrm,
          hls::stream<bool>& eLenStrm,
          hls::stream<ap_uint<hshW> >& hshStrm,
          hls::stream<bool>& eHshStrm) {
    hmac_optimized<dataW, lW, hshW, keyLen, blockSize, F>(keyStrm, msgStrm, msgLenStrm, eLenStrm, hshStrm, eHshStrm);
}

} // end of namespace security
} // end of namespace xf

#endif // _XF_SECURITY_HMAC_HPP_
