Header files of XF Solver Library Level-2

## License

 Copyright © 2019–2023 Advanced Micro Devices, Inc

Terms and Conditions <https://www.amd.com/en/corporate/copyright>
