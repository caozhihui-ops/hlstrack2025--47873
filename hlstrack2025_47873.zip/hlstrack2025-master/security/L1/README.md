## Level 1: HLS Functions and Modules

The Level 1 APIs are presented as HLS C++ classes and functions.

This level of API is mainly provide for hardware-savvy HLS developers.The API description and design details of these modules can be found in L1 Module User Guide section of the [library documentation](https://docs.xilinx.com/r/en-US/Vitis_Libraries/security/index.html).
