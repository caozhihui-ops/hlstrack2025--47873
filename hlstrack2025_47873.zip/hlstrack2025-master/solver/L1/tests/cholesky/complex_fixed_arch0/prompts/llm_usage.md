# 大模型辅助使用记录

## 基本信息

- **模型名称**：豆包
  -
- **使用日期**：YYYY-MM-DD
- **项目名称**：AES-128 GMAC L1 算子优化

---

## 使用场景 1

### 主要用途
 性能优化建议 

完整 Prompt 内容
/*
 * Copyright 2021 Xilinx, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @file xf_solver_L1.h
 * @brief Top-levle header for XF Solver Libaray level-1.
 */

#ifndef _XF_SOLVER_L1_HPP_
#define _XF_SOLVER_L1_HPP_

#include "hw/pseudosqrt.hpp"
#include "hw/qrf.hpp"
#include "hw/qr_inverse.hpp"
#include "hw/svd.hpp"
#include "hw/cholesky_inverse.hpp"
#include "hw/cholesky.hpp"

#endif
优化建议
### 模型输出摘要
一、统一模板参数与接口标准化，减少冗余与冲突
问题分析
线性代数求解器（QR、SVD、Cholesky 等）均涉及矩阵运算，存在大量共性参数（如矩阵维度、数据位宽、小数精度）和接口（如矩阵输入 / 输出、状态信号）。当前头文件仅简单包含子模块，未统一参数与接口，易导致子模块间参数不一致、接口适配成本高。
优化建议
定义通用模板参数集合在顶层头文件中定义统一的模板参数结构体，封装矩阵维度、数据类型（定点 / 浮点）、位宽等共性参数，子模块通过继承或引用该结构体实现参数一致性。// 新增：通用模板参数结构体
template <int N,          // 矩阵维度（最大支持维度）
          int DataWidth,  // 数据位宽（如32/64）
          int FractionalBits,  // 定点数小数位（若为浮点可设0）
          bool UseFloat = false>  // 是否使用浮点类型
struct SolverParams {
    static const int dim = N;
    static const int data_width = DataWidth;
    static const int frac_bits = FractionalBits;
    using DataType = typename std::conditional<UseFloat, 
                                               float, 
                                               ap_fixed<DataWidth, DataWidth - FractionalBits>>::type;
};
标准化数据接口统一矩阵输入 / 输出接口类型，避免子模块使用不同的流（hls::stream）或内存映射（MM）格式。例如，定义通用矩阵流接口和状态信号：// 新增：标准化矩阵流接口（按行/列传输元素）
template <typename Params>
using MatrixStream = hls::stream<typename Params::DataType>;

// 新增：状态信号流（用于标记帧开始/结束、错误等）
using StatusStream = hls::stream<ap_uint<2>>;  // 0: idle, 1: valid, 2: error
### 人工审核与采纳情况
基本采纳
总结

整体贡献度评估
大模型在本项目中的总体贡献占比：约 10%
- 主要帮助领域：“调试分析


学习收获
通过与大模型交互，我学会了代码修改的诸多思路。


## 附注

- 请确保填写真实、完整的使用记录
- 如未使用大模型辅助，请在此文件中注明"本项目未使用大模型辅助"
- 评审方将参考此记录了解项目的独立性与创新性
